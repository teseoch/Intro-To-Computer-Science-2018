package gol;


public class GliderConfiguration {
	private static final int[][] cells = {{0, 1}, {1, 2}, {2, 0}, {2, 1}, {2, 2}};

	public void draw(int i, int j, Grid grid) {
		for(int index = 0; index < cells.length; ++index)
		{
			grid.set(i+cells[index][0], j+cells[index][1], true);
		}
	}
}
