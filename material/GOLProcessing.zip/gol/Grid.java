package gol;


public class Grid {
	private static final String aliveString = "" + '\u2B1B';
	private static final String deadString = "  ";
	
	private boolean[][] data;
	private int width;
	private int height;

	public Grid(int n, int m) {
		data = new boolean[n][m];
		height = n;
		width = m;
		
		for(int i = 0; i < width; ++i)
		{
			for(int j = 0; j < height; ++j)
			{
				set(i,j,false);
			}
		}
	}

	public Grid(int n, int m, double aliveProbability)
	{
		this(n, m);
		
		for(int  i = 0; i < width; ++i)
		{
			for(int  j = 0; j < height; ++j)
			{
				set(i,j, Math.random() < aliveProbability);
			}
		}
	}
	
	
	public void print()
	{
		for(int  i = 0; i < width; ++i)
		{
			for(int  j = 0; j < height; ++j)
			{
				if(get(i,j))
				{
					System.out.print(aliveString);
				}
				else
				{
					System.out.print(deadString);
				}
			}

			// System.out.println("");
			System.out.print("\n");
		}
	}
	
	public void update()
	{
		boolean[][] newData = new boolean[height][width];

		for(int  i = 0; i < width; ++i)
		{
			for(int  j = 0; j < height; ++j)
			{
				int aliveNeighs = getNNeighs(i, j);

				if(get(i,j))
				{
					if(aliveNeighs < 2)
					{
						newData[i][j] = false;
					}
					else if(aliveNeighs == 2 || aliveNeighs == 3)
					{
						newData[i][j] = true;
					}
					else
					{
						//more than 3
						newData[i][j] = false;
					}
				}
				else //the cell is dead
				{
					if(aliveNeighs == 3)
					{
						newData[i][j] = true;
					}
					else
					{
						newData[i][j] = false;
					}
				}
			}
		}

		for(int  i = 0; i < width; ++i)
		{
			for(int  j = 0; j < height; ++j)
			{
				this.data[i][j] = newData[i][j];
			}
		}
	}
	
	public boolean get(int i, int j)
	{
		int indexI = (i + width) % width;
		int indexJ = (j + height) % height;

		return data[indexI][indexJ];
	}
	
	public void set(int i, int j, boolean v)
	{
		int indexI = (i + width) % width;
		int indexJ = (j + height) % height;

		data[indexI][indexJ] = v;
	}
	
	private int getNNeighs(int indexI, int indexJ)
	{
		int startI = indexI - 1;
		int startJ = indexJ - 1;

		int endI = indexI + 1;
		int endJ = indexJ + 1;

		int counter = 0;
		for(int i = startI; i <= endI; ++i)
		{
			for(int j = startJ; j <= endJ; ++j)
			{
				if(i == indexI && j == indexJ)
					continue;

				if(get(i,j))
					counter++;
			}
		}

		return counter;
	}
	
	
	
	
	
	
	public static void main(String[] args) {
		Grid g = new Grid(10,10);
	
//		SquareConfiguration c = new SquareConfiguration();
		GliderConfiguration c = new GliderConfiguration();
		c.draw(0, 0, g);
		
		c.draw(5, 5, g);
		
		g.print();
	}

	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}
}
