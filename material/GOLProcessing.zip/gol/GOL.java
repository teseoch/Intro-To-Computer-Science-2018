package gol;


public class GOL {

	public static void main(String[] args) throws InterruptedException {
		int n = 20;
//		double probability = 0.1;
		
		Grid g = new Grid(n, n);
		PentadecathlonConfiguration c = new PentadecathlonConfiguration();
		c.draw(0, 10, g);
		
		while(true)
		{
//			System.out.print("\033[H\033[2J");
//			System.out.flush();


			g.print();
			g.update();

			Thread.sleep(100);

		}
	}

}
