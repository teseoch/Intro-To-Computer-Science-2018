package processing;

import gol.Grid;
import processing.core.PApplet;

public class GOLProcessing extends PApplet {

	public static void main(String[] args) {
		PApplet.main("processing.GOLProcessing");
	}

	Grid g;

	private int n = 60;
	private int cellSize = 10;
	private long lastUpdate = 0;
	private boolean paused = false;

	public void settings() {
		size(n*cellSize, n*cellSize);
	}

	public void setup()
	{
		g = new Grid(n, n, 0.5);
	}
	
	public void keyPressed() {
		if(key == ' ')
			paused = !paused;
	}


	public void draw(){
		background(0);
		
		
		int gi = mouseX/cellSize;
		int gj = mouseY/cellSize;
		
		if (mousePressed) {
			if(mouseButton == LEFT)
				g.set(gi, gj, true);
			else
				g.set(gi, gj, false);
		}
		
		long currentTime = millis();
		if(!paused && lastUpdate + 100 < currentTime)
		{
			g.update();
			lastUpdate = currentTime;
		}
		
		

		
		fill(255, 255, 0);
		for(int  i = 0; i < g.getWidth(); ++i)
		{
			for(int  j = 0; j < g.getHeight(); ++j)
			{
				if(g.get(i,j))
				{
					rect(i*cellSize, j*cellSize, cellSize, cellSize);
				}
			}
		}
	}

}
